export default function Summary() {
    return (
        <>
            Resumen
        </>
    )
}
