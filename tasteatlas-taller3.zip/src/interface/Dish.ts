export interface Dish {
  position: number
  title: string
  subtitle: string
  rating: number
  country: string
  iconic: string
  ingredients: string
}
